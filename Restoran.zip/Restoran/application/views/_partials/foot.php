<!-- jquery 3.3.1 -->
<script src="<?php echo base_url() ?>assets/concept-master/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<!-- bootstap bundle js -->
<script src="<?php echo base_url() ?>assets/concept-master/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<!-- slimscroll js -->
<script src="<?php echo base_url() ?>assets/concept-master/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<!-- main js -->
<script src="<?php echo base_url() ?>assets/concept-master/assets/libs/js/main-js.js"></script>